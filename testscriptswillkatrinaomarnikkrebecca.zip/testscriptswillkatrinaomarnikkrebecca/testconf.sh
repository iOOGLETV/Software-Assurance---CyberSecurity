#/bin/bash
#This is to test the process to see if it is running or not. Good Luck
Echo "Test at your own risk"
uname >>testconf.txt
date >>testconf.txt

read -p "enter process : " process
var=`ps -ef | grep "$process" | grep -v "grep $process"`

if [ -z "$var" ]; then
  echo "$process Process is **not** running">>testconf.txt
else
  echo "$process Process is  running">>testconf.txt
  echo "$var"
fi
echo "You are done now with the test of your life">>testconf.txt
