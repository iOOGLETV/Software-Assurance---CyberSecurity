#!/usr/bin/python
import os

print "This python script will delete the authentication log file from a Linux computer."

## Log file location ##
filename = "/home/nikki/Documents/Plans.docx"

## Check if file path can be found ##
if os.path.exists(filename):
    os.remove(filename)
else:
    print("Unable to find the file dude, It may not exist, or this may not be a linux machine?")
    